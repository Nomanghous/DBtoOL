﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesstoOutlook
{
    class Passvalues
    {
        public static string connectionString = "";
        public static string message = "";
        public static string totalRecords = "0.0";
        public static string lastUpdateDate= "";
    }
}
